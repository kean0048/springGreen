# SpringGreen
* 资源包预览图
>
isOk/
├── ACYL_Icon_Theme_0.9.4                                
├── Breeze-Hacked
├── Breeze-White
├── fonts
├── Kali-X
├── ReadMe
└── springgreen_Acvamarin_theme

* 主题文件夹
>/.themes 或者  /usr/share/themes
 **springgreen_Acvamarin_theme **
（作为gnome-shell和GTK+主题使用)
**Kali-X **
(作为窗口主题使用, 在/usr/share/themes中已存在，需先备份一下，否则就要覆盖了。)

* 鼠标主题
>/.icons 或 /usr/share/icons
 **Breeze-White**
**Breeze-Hacked**
两套主题

* 图标主题
>/.icons 或 /usr/share/icons
在ACYL icon Theme 0.94/scalable/scripts中有个py脚本（带GUI），可任意生成不同风格
不同颜色的主题包。

* 字体文件
>./fonts 或 /usr/share/fonts
建议使用**profontwindows** 作为终端字体，9pt最佳。
建议使用** YosemiteSanFranciscoFont-master**作界面主题使用。
建议使用**zfull-GB** 位图汉字字体，号称最小的汉字显示，依旧清晰。

备注：


> @键盘雀跃
> E-Mail:tkcaper@yeah.net



